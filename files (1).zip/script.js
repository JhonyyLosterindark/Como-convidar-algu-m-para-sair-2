/* script.js
   Lógica para:
   - Fazer o botão "NÃO" fugir (hover no desktop, touch em mobile, focus/keyboard)
   - Mostrar mensagem e criar celebração quando clicar em "SIM"
   - Criar corações flutuantes de fundo
   Comentários explicam os trechos principais.
*/

(function(){
  // Elementos principais
  const stage = document.getElementById('stage');
  const noBtn = document.getElementById('noBtn');
  const yesBtn = document.getElementById('yesBtn');
  const message = document.getElementById('message');
  const celebrateLayer = document.getElementById('celebrateLayer');
  const floatingHearts = document.getElementById('floatingHearts');

  // Configurações
  const MARGIN = 14; // margem do botão em relação às bordas da stage
  const MIN_DISTANCE = 120; // distância mínima do "NÃO" ao botão "SIM" ao posicionar
  const BG_HEARTS = 8; // número de corações de fundo

  // Gera uma posição aleatória segura para o botão "NÃO"
  function getRandomPositionForButton(){
    const stageRect = stage.getBoundingClientRect();
    const btnRect = noBtn.getBoundingClientRect();
    const yesRect = yesBtn.getBoundingClientRect();

    const maxLeft = Math.max(stageRect.width - btnRect.width - MARGIN, MARGIN);
    const maxTop = Math.max(stageRect.height - btnRect.height - MARGIN, MARGIN);

    let left, top, attempts = 0;
    do {
      left = MARGIN + Math.random() * (maxLeft - MARGIN);
      top  = MARGIN + Math.random() * (maxTop - MARGIN);
      attempts++;
      // compute centers to ensure min distance from yes button
      const centerX = left + btnRect.width / 2;
      const centerY = top + btnRect.height / 2;
      const yesCenterX = (yesRect.left - stageRect.left) + yesRect.width / 2;
      const yesCenterY = (yesRect.top - stageRect.top)  + yesRect.height / 2;
      const dx = centerX - yesCenterX;
      const dy = centerY - yesCenterY;
      const dist = Math.sqrt(dx*dx + dy*dy);
      if(dist > MIN_DISTANCE) break;
      // safety: after several attempts, relax constraint
      if(attempts > 10) break;
    } while(true);

    return { left, top };
  }

  // Aplica a posição com suavidade (CSS transition handles the smoothness)
  function moveNoButton(){
    const pos = getRandomPositionForButton();
    // position is relative to stage's content box: set left/top in px
    noBtn.style.left = pos.left + 'px';
    noBtn.style.top  = pos.top + 'px';
    // pequena reação do botão "SIM" quando o "NÃO" foge
    triggerYesPulse();
  }

  // animação rápida no botão SIM para torná-lo mais atraente
  function triggerYesPulse(){
    yesBtn.classList.add('pulse');
    // remove a classe após a animação
    setTimeout(()=> yesBtn.classList.remove('pulse'), 500);
  }

  // Ao clicar SIM: mostra mensagem e dispara celebração
  function celebrate(){
    // esconder botões e apresentar mensagem
    document.getElementById('buttons').classList.add('hidden');
    message.classList.remove('hidden');

    // criar muitos corações na camada de celebração
    for(let i=0;i<22;i++){
      createCelebrateHeart();
    }

    // opcional: criar uma segunda mensagem personalizada após alguns segundos
    // (mantive curta para não atrapalhar a interação)
    setTimeout(()=>{
      const p = document.createElement('p');
      p.className = 'mini';
      p.innerHTML = 'Mal posso esperar pelo nosso encontro. ❤️';
      message.appendChild(p);
    }, 1200);
  }

  // Cria um coração animado que sobe/afasta do centro
  function createCelebrateHeart(){
    const el = document.createElement('div');
    el.className = 'celebrate-heart';
    // usar emoji de coração para simplicidade e leveza
    el.textContent = ['💖','💘','💞','❤️'][Math.floor(Math.random()*4)];
    // posicionar inicialmente próximo ao centro do card
    const cardRect = document.querySelector('.card').getBoundingClientRect();
    const stageRect = stage.getBoundingClientRect();
    const startX = (cardRect.left - stageRect.left) + (cardRect.width/2) + (Math.random()*80 - 40);
    const startY = (cardRect.top - stageRect.top) + (cardRect.height/2) + (Math.random()*40 - 20);
    el.style.left = startX + 'px';
    el.style.top = startY + 'px';
    // custom properties para variar direção e rotação
    el.style.setProperty('--dx', (Math.random()*160 - 80) + 'px');
    el.style.setProperty('--rot', (Math.random()*90 - 45) + 'deg');
    // duração e delay leves
    el.style.animationDuration = (900 + Math.random()*700) + 'ms';
    celebrateLayer.appendChild(el);
    // remover quando terminar a animação
    setTimeout(()=> {
      el.remove();
    }, 2200);
  }

  // Cria corações de fundo sutis que flutuam (apenas decorativo)
  function createBackgroundHearts(){
    const stageRect = stage.getBoundingClientRect();
    for(let i=0;i<BG_HEARTS;i++){
      const h = document.createElement('div');
      h.className = 'bg-heart';
      h.textContent = '❤';
      const size = 10 + Math.random()*20;
      h.style.position = 'absolute';
      h.style.left = (Math.random()*100) + '%';
      h.style.bottom = (-10 - Math.random()*30) + 'px';
      h.style.fontSize = size + 'px';
      h.style.opacity = (0.08 + Math.random()*0.3).toString();
      const dur = 9000 + Math.random()*10000;
      const delay = Math.random()*3000;
      h.style.animation = `floatUp ${dur}ms linear ${delay}ms forwards`;
      floatingHearts.appendChild(h);
      // remove após a animação para evitar acúmulo
      setTimeout(()=> h.remove(), dur + delay + 500);
      // tempo para recriar novos e manter background vivo
      setTimeout(()=> {
        if(floatingHearts) createBackgroundHearts();
      }, dur + delay + 1500);
    }
  }

  // --- Event listeners ---

  // Hover mouseenter (desktop) - quando o mouse entra no botão, ele foge
  noBtn.addEventListener('mouseenter', (e)=>{
    // mover com pequeno atraso para permitir animação suave
    moveNoButton();
  });

  // Touch (mobile): ao tocar, o botão se move imediatamente
  noBtn.addEventListener('touchstart', (e)=>{
    e.preventDefault(); // evitamos o click que poderia ocorrer
    moveNoButton();
  }, {passive:false});

  // Focus (teclado) também faz o botão se mover (acessibilidade)
  noBtn.addEventListener('focus', moveNoButton);

  // Se o usuário conseguir clicar no botão "NÃO" (ex: via teclado), movemos e evitamos ação
  noBtn.addEventListener('click', (e)=>{
    e.preventDefault();
    moveNoButton();
  });

  // Botão SIM: clique para aceitar
  yesBtn.addEventListener('click', (e)=>{
    celebrate();
  });

  // Quando a janela redimensiona, reposicionamos o botão caso esteja fora dos limites
  window.addEventListener('resize', ()=>{
    // força um ajuste suave para manter visibilidade
    const stageRect = stage.getBoundingClientRect();
    const btnRect = noBtn.getBoundingClientRect();
    // se estiver fora do novo tamanho, reposiciona
    if(btnRect.right > stageRect.right || btnRect.bottom > stageRect.bottom){
      moveNoButton();
    }
  });

  // Inicializações
  // posiciona o botão NÃO em um lugar inicial seguro (relativo à stage)
  function init(){
    // Garantir que o botão seja absoluto relativo ao stage:
    // calcula posição inicial central direita do container de botões
    const buttonsRect = document.getElementById('buttons').getBoundingClientRect();
    const stageRect = stage.getBoundingClientRect();
    // set initial position near the buttons area
    noBtn.style.left = ( (buttonsRect.left - stageRect.left) + buttonsRect.width + 28 ) + 'px';
    noBtn.style.top = ( (buttonsRect.top - stageRect.top) + buttonsRect.height/2 ) + 'px';

    // Cria fundo de corações sutilmente animados
    createBackgroundHearts();
  }

  // run
  init();

})();